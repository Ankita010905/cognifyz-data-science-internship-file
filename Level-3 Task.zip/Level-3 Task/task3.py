import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set(style="whitegrid")

df = pd.read_csv("feature_engineered_dataset.csv")
print(df.head())

plt.figure(figsize=(8,5))
sns.histplot(df['Aggregate rating'], bins=20, kde=True, color='skyblue')
plt.title("Distribution of Aggregate Ratings")
plt.xlabel("Aggregate Rating")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("rating_distribution_hist.png")
plt.show()

avg_rating_city = df.groupby('City')['Aggregate rating'].mean().sort_values(ascending=False).head(10)

plt.figure(figsize=(10,5))
avg_rating_city.plot(kind='bar', color='coral')
plt.title("Top 10 Cities by Average Restaurant Rating")
plt.xlabel("City")
plt.ylabel("Average Rating")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("avg_rating_city.png")
plt.show()

# Handle multiple cuisines
df_cuisines = df.assign(Cuisine=df['Cuisines'].str.split(',')).explode('Cuisine')
df_cuisines['Cuisine'] = df_cuisines['Cuisine'].str.strip()

avg_rating_cuisine = df_cuisines.groupby('Cuisine')['Aggregate rating'].mean().sort_values(ascending=False).head(10)

plt.figure(figsize=(10,5))
avg_rating_cuisine.plot(kind='bar', color='green')
plt.title("Top 10 Cuisines by Average Rating")
plt.xlabel("Cuisine")
plt.ylabel("Average Rating")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("avg_rating_cuisine.png")
plt.show()

plt.figure(figsize=(8,5))
sns.boxplot(x='Has Table booking', y='Aggregate rating', data=df)
plt.title("Impact of Table Booking on Ratings")
plt.xlabel("Has Table Booking")
plt.ylabel("Aggregate Rating")
plt.tight_layout()
plt.savefig("table_booking_vs_rating.png")
plt.show()

plt.figure(figsize=(8,5))
sns.boxplot(x='Has Online delivery', y='Aggregate rating', data=df)
plt.title("Impact of Online Delivery on Ratings")
plt.xlabel("Has Online Delivery")
plt.ylabel("Aggregate Rating")
plt.tight_layout()
plt.savefig("online_delivery_vs_rating.png")
plt.show()

plt.figure(figsize=(8,5))
sns.scatterplot(x='Price range', y='Aggregate rating', data=df, hue='Price range', palette='viridis', alpha=0.7)
plt.title("Price Range vs Aggregate Rating")
plt.xlabel("Price Range")
plt.ylabel("Aggregate Rating")
plt.tight_layout()
plt.savefig("price_range_vs_rating.png")
plt.show()

