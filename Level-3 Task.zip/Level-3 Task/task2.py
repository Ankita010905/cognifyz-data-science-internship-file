import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("feature_engineered_dataset.csv")

df_cuisines = df.copy()
df_cuisines['Cuisines'] = df_cuisines['Cuisines'].astype(str)
df_cuisines = df_cuisines.assign(Cuisine=df_cuisines['Cuisines'].str.split(',')).explode('Cuisine')
df_cuisines['Cuisine'] = df_cuisines['Cuisine'].str.strip()

avg_rating_cuisine = df_cuisines.groupby('Cuisine')['Aggregate rating'].mean().sort_values(ascending=False)

popular_cuisines = df_cuisines.groupby('Cuisine')['Votes'].sum().sort_values(ascending=False)

avg_rating_cuisine.head(10).to_csv("top10_cuisine_avg_rating.csv", encoding='utf-8')
popular_cuisines.head(10).to_csv("top10_cuisine_popularity.csv", encoding='utf-8')

print(" Top 10 cuisines saved to CSV successfully!")

avg_rating_cuisine.head(10).plot(kind='bar', color='orange')
plt.title("Top 10 Cuisines by Average Rating")
plt.ylabel("Average Rating")
plt.xlabel("Cuisine")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("top10_cuisine_avg_rating.png")
plt.show()

popular_cuisines.head(10).plot(kind='bar', color='green')
plt.title("Top 10 Most Popular Cuisines (Votes)")
plt.ylabel("Total Votes")
plt.xlabel("Cuisine")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("top10_cuisine_popularity.png")
plt.show()
