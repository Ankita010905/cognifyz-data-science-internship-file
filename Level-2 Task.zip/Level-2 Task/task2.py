import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("cleaned_dataset.csv")

most_common_price_range = df['Price range'].value_counts()

print("Most Common Price Range:")
print(most_common_price_range)

avg_rating_price_range = df.groupby('Price range')['Aggregate rating'].mean()

print("\nAverage Rating by Price Range:")
print(avg_rating_price_range)

avg_rating_color = df.groupby('Rating color')['Aggregate rating'].mean()

print("\nAverage Rating by Rating Color:")
print(avg_rating_color)

highest_rating_color = avg_rating_color.idxmax()
print("\nColor Representing Highest Average Rating:", highest_rating_color)

avg_rating_price_range.plot(kind='bar')
plt.title("Average Rating by Price Range")
plt.xlabel("Price Range")
plt.ylabel("Average Rating")
plt.tight_layout()
plt.savefig("avg_rating_by_price_range.png")
plt.show()

