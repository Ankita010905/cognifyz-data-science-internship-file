import pandas as pd

df = pd.read_csv("cleaned_dataset.csv")

df['Restaurant_Name_Length'] = df['Restaurant Name'].str.len()

df['Address_Length'] = df['Address'].str.len()



df['Has_Table_Booking_Feature'] = df['Has Table booking'].apply(
    lambda x: 1 if str(x).lower() == 'yes' else 0
)

df['Has_Online_Delivery_Feature'] = df['Has Online delivery'].apply(
    lambda x: 1 if str(x).lower() == 'yes' else 0
)


print(
    df[
        [
            'Restaurant_Name_Length',
            'Address_Length',
            'Has_Table_Booking_Feature',
            'Has_Online_Delivery_Feature'
        ]
    ].head()
)


df.to_csv("feature_engineered_dataset.csv", index=False)

print("\n Feature Engineering completed successfully!")
