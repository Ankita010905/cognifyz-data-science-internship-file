import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("cleaned_dataset.csv")

table_booking_percentage = (df['Has Table booking'].value_counts(normalize=True) * 100)
online_delivery_percentage = (df['Has Online delivery'].value_counts(normalize=True) * 100)

print("Percentage of Restaurants with Table Booking:")
print(table_booking_percentage)

print("\nPercentage of Restaurants with Online Delivery:")
print(online_delivery_percentage)

avg_rating_table_booking = df.groupby('Has Table booking')['Aggregate rating'].mean()
print("\nAverage Ratings based on Table Booking:")
print(avg_rating_table_booking)

avg_rating_table_booking.plot(kind='bar')
plt.title("Average Rating: Table Booking vs No Table Booking")
plt.ylabel("Average Rating")
plt.xlabel("Table Booking Availability")
plt.tight_layout()
plt.savefig("avg_rating_table_booking.png")
plt.show()

delivery_price_analysis = pd.crosstab(
    df['Price range'],
    df['Has Online delivery'],
    normalize='index'
) * 100

print("\nOnline Delivery Availability by Price Range:")
print(delivery_price_analysis)

delivery_price_analysis.plot(kind='bar', stacked=True)
plt.title("Online Delivery Availability by Price Range")
plt.ylabel("Percentage")
plt.xlabel("Price Range")
plt.legend(title="Online Delivery")
plt.tight_layout()
plt.savefig("online_delivery_price_range.png")
plt.show()

