import pandas as pd
import matplotlib.pyplot as plt
from collections import Counter

df = pd.read_csv("Dataset .csv")
print("Dataset loaded successfully!")
print(df.head())

print("\nBasic statistical measures for numerical columns:")
print(df.describe())

print("\nNumerical columns:")
print(df.select_dtypes(include=['int64', 'float64']).columns)

print("\nTop 10 Country Codes:")
print(df['Country Code'].value_counts().head(10))

print("\nTop 10 Cities with most restaurants:")
print(df['City'].value_counts().head(10))

from collections import Counter

all_cuisines = df['Cuisines'].dropna().str.split(', ')
cuisine_list = [cuisine for sublist in all_cuisines for cuisine in sublist]

top_cuisines = Counter(cuisine_list).most_common(10)

print("\nTop 10 Cuisines:")
for cuisine, count in top_cuisines:
    print(cuisine, ":", count)

df['City'].value_counts().head(10).plot(kind='bar')
plt.xlabel("City")
plt.ylabel("Number of Restaurants")
plt.title("Top 10 Cities with Most Restaurants")
plt.show()
