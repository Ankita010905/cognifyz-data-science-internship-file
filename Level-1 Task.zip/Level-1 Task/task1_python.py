import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
df = pd.read_csv("Dataset .csv")  
print("First 5 rows of dataset:")
print(df.head())

#to get the number of rows and columns of dataset
print("\nDataset Shape (rows, columns):")
print(df.shape)

#datatypes
print("\nDataset Information:")
print(df.info())

#checking missing values
print("\nMissing values in each column:")
print(df.isnull().sum())

df['Aggregate rating'].fillna(df['Aggregate rating'].mean(), inplace=True)
df['Cuisines'].fillna(df['Cuisines'].mode()[0], inplace=True)

print("\nAggregate Rating Summary:")
print(df['Aggregate rating'].describe())
plt.hist(df['Aggregate rating'], bins=10)
plt.xlabel("Aggregate Rating")
plt.ylabel("Frequency")
plt.title("Distribution of Aggregate Rating")
plt.show()

print("\nAggregate Rating Counts:")
print(df['Aggregate rating'].value_counts())
df.to_csv("cleaned_dataset.csv", index=False)

print("\nTask 1 completed successfully ✅")