import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Dataset .csv")
print("Dataset loaded successfully")

geo_df = df[['Latitude', 'Longitude', 'Aggregate rating', 'City', 'Country Code']].dropna()

plt.figure(figsize=(8, 6))
plt.scatter(geo_df['Longitude'], geo_df['Latitude'],
            c=geo_df['Aggregate rating'], cmap='viridis', alpha=0.6)

plt.colorbar(label='Restaurant Rating')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('Geographical Distribution of Restaurants')
plt.show()

print("\nTop 10 Cities with Most Restaurants:")
print(df['City'].value_counts().head(10))

print("\nTop 10 Countries with Most Restaurants:")
print(df['Country Code'].value_counts().head(10))

lat_corr = geo_df['Latitude'].corr(geo_df['Aggregate rating'])
lon_corr = geo_df['Longitude'].corr(geo_df['Aggregate rating'])

print("\nCorrelation Analysis:")
print("Latitude vs Rating:", lat_corr)
print("Longitude vs Rating:", lon_corr)

plt.figure(figsize=(7,5))
plt.scatter(geo_df['Latitude'], geo_df['Aggregate rating'], alpha=0.5)
plt.xlabel("Latitude")
plt.ylabel("Aggregate Rating")
plt.title("Latitude vs Restaurant Rating")
plt.show()

